After the Domain is created, login to the windows server and create a user with Admin, Domain Admin, Domain User permissions. 
This User can be used when creating the windows clients
