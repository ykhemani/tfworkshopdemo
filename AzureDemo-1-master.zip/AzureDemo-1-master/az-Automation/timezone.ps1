configuration timezone {
    Import-DscResource -ModuleName ComputerManagementDsc -ModuleVersion 6.1.0.0

    TimeZone TimeZoneExample {
        IsSingleInstance = 'Yes'
        TimeZone = 'W. Europe Standard Time'
    }
}
timezone
